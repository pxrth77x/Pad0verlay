package com.example.padoverlay

import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.os.*
import android.view.*
import android.view.WindowManager.LayoutParams.*

const val BTN = 0; const val PILL = 1; const val SMALL = 2; const val STICK = 3

/** One on-screen control. key = Android keycode, axis = axis index in Injector (-1 none), fx/fy = default centre (screen fraction), r = radius in dp. */
data class C(val id: String, val label: String, val sub: String, val kind: Int, val key: Int,
             val axis: Int, val fx: Float, val fy: Float, val r: Float, val col: Int = 0)

val K = KeyEvent::class.java
val CONTROLS = listOf(
    // Shoulders / triggers (layout from your image: LT target lock, LB weapon wheel, RT fire, RB take cover)
    C("LT", "LT", "Target lock", PILL, KeyEvent.KEYCODE_BUTTON_L2, 4, .07f, .10f, 30f),
    C("LB", "LB", "Weapon wheel", PILL, KeyEvent.KEYCODE_BUTTON_L1, -1, .07f, .26f, 30f),
    C("RT", "RT", "Fire", PILL, KeyEvent.KEYCODE_BUTTON_R2, 5, .93f, .10f, 30f),
    C("RB", "RB", "Take cover", PILL, KeyEvent.KEYCODE_BUTTON_R1, -1, .93f, .26f, 30f),
    // Centre buttons
    C("BACK", "\u29C9", "Camera", SMALL, KeyEvent.KEYCODE_BUTTON_SELECT, -1, .43f, .08f, 22f),
    C("START", "\u2261", "Pause", SMALL, KeyEvent.KEYCODE_BUTTON_START, -1, .57f, .08f, 22f),
    // Left stick (move) + L3 (stealth)
    C("LS", "", "Move", STICK, 0, 0, .13f, .66f, 62f),
    C("L3", "L3", "Stealth", SMALL, KeyEvent.KEYCODE_BUTTON_THUMBL, -1, .26f, .42f, 24f),
    // D-pad: up phone, left phone left, down character switch, right phone right
    C("DU", "\u25B2", "Phone", BTN, KeyEvent.KEYCODE_DPAD_UP, -1, .33f, .62f, 25f),
    C("DL", "\u25C0", "Ph.Left", BTN, KeyEvent.KEYCODE_DPAD_LEFT, -1, .27f, .78f, 25f),
    C("DR", "\u25B6", "Ph.Right", BTN, KeyEvent.KEYCODE_DPAD_RIGHT, -1, .39f, .78f, 25f),
    C("DD", "\u25BC", "Char", BTN, KeyEvent.KEYCODE_DPAD_DOWN, -1, .33f, .93f, 25f),
    // Face buttons: Y enter vehicle, B reload, A sprint, X jump
    C("Y", "Y", "Vehicle", BTN, KeyEvent.KEYCODE_BUTTON_Y, -1, .88f, .40f, 28f, 0xFFE0A800.toInt()),
    C("X", "X", "Jump", BTN, KeyEvent.KEYCODE_BUTTON_X, -1, .80f, .55f, 28f, 0xFF1E6FD9.toInt()),
    C("B", "B", "Reload", BTN, KeyEvent.KEYCODE_BUTTON_B, -1, .96f, .55f, 28f, 0xFFC01818.toInt()),
    C("A", "A", "Sprint", BTN, KeyEvent.KEYCODE_BUTTON_A, -1, .88f, .70f, 28f, 0xFF4FA800.toInt()),
    // Right stick (look) + R3 (look behind)
    C("RS", "", "Look", STICK, 0, 2, .68f, .76f, 62f),
    C("R3", "R3", "Look behind", SMALL, KeyEvent.KEYCODE_BUTTON_THUMBR, -1, .60f, .52f, 24f)
)

class CtlView(ctx: Context, val c: C, val svc: OverlayService) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var pressed = false
    private var kx = 0f; private var ky = 0f
    private var ox = 0f; private var oy = 0f

    override fun onDraw(cv: Canvas) {
        val a = (svc.alphaPct() * 2.55f).toInt().coerceIn(25, 255)
        val w = width.toFloat(); val h = height.toFloat(); val m = h * 0.04f
        val base = if (c.col != 0) c.col else 0xFF2B2B2B.toInt()
        val fill = if (pressed) Color.WHITE else base
        p.style = Paint.Style.FILL; p.color = Color.argb(a, Color.red(fill), Color.green(fill), Color.blue(fill))
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = h * 0.04f
            color = Color.argb(a, 255, 255, 255)
        }
        val t = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; color = if (pressed) Color.BLACK else Color.argb(a, 255, 255, 255) }
        when (c.kind) {
            STICK -> {
                cv.drawCircle(w / 2, h / 2, h / 2 - m, stroke)
                p.color = Color.argb(a, 70, 70, 70)
                cv.drawCircle(w / 2 + kx, h / 2 + ky, h * 0.30f, p)
                cv.drawCircle(w / 2 + kx, h / 2 + ky, h * 0.30f, stroke)
                t.textSize = h * 0.12f; cv.drawText(c.sub, w / 2 + kx, h / 2 + ky + h * 0.04f, t)
            }
            PILL -> {
                val rc = RectF(m, h * 0.12f, w - m, h * 0.88f)
                cv.drawRoundRect(rc, h * 0.38f, h * 0.38f, p); cv.drawRoundRect(rc, h * 0.38f, h * 0.38f, stroke)
                t.textSize = h * 0.30f; cv.drawText(c.label, w / 2, h * 0.47f, t)
                t.textSize = h * 0.17f; cv.drawText(c.sub, w / 2, h * 0.72f, t)
            }
            else -> {
                cv.drawCircle(w / 2, h / 2, h / 2 - m, p); cv.drawCircle(w / 2, h / 2, h / 2 - m, stroke)
                t.textSize = h * (if (c.kind == SMALL) 0.28f else 0.34f); cv.drawText(c.label, w / 2, h * 0.50f, t)
                t.textSize = h * 0.16f; cv.drawText(c.sub, w / 2, h * 0.74f, t)
            }
        }
    }

    private fun stick(e: MotionEvent) {
        val r = width * 0.4f
        var dx = e.x - width / 2f; var dy = e.y - height / 2f
        val d = Math.hypot(dx.toDouble(), dy.toDouble()).toFloat()
        if (d > r) { dx *= r / d; dy *= r / d }
        kx = dx; ky = dy
        Injector.axis(c.axis, dx / r, dy / r)
    }

    private fun drag(e: MotionEvent): Boolean {
        val lp = layoutParams as WindowManager.LayoutParams
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { ox = e.rawX - lp.x; oy = e.rawY - lp.y }
            MotionEvent.ACTION_MOVE -> { lp.x = (e.rawX - ox).toInt(); lp.y = (e.rawY - oy).toInt(); svc.wm.updateViewLayout(this, lp) }
            MotionEvent.ACTION_UP -> svc.savePos(c, lp.x + width / 2f, lp.y + height / 2f)
        }
        return true
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (svc.edit) return drag(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                pressed = true
                if (c.kind == STICK) stick(e) else { Injector.key(c.key, true); if (c.axis >= 4) Injector.axis(c.axis, 1f) }
            }
            MotionEvent.ACTION_MOVE -> if (c.kind == STICK) stick(e)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                pressed = false
                if (c.kind == STICK) { kx = 0f; ky = 0f; Injector.axis(c.axis, 0f, 0f) }
                else { Injector.key(c.key, false); if (c.axis >= 4) Injector.axis(c.axis, 0f) }
            }
        }
        invalidate(); return true
    }
}

class OverlayService : Service() {
    companion object { var inst: OverlayService? = null }
    lateinit var wm: WindowManager
    private val views = mutableListOf<CtlView>()
    private val h = Handler(Looper.getMainLooper())
    var edit = false
    private var fg = ""; private var lastQ = 0L; private var shown = false; private var sw = 0
    private val tick = object : Runnable { override fun run() { poll(); h.postDelayed(this, 800) } }

    override fun onBind(i: Intent?): IBinder? = null
    fun prefs() = getSharedPreferences("cfg", 0)
    fun alphaPct() = prefs().getInt("alpha", 60)

    override fun onCreate() {
        super.onCreate(); inst = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("pad", "Gamepad overlay", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "pad").setContentTitle("Gamepad overlay running")
            .setContentText("Shows on selected apps").setSmallIcon(android.R.drawable.ic_menu_manage).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
        Thread { Injector.init() }.start()
        h.post(tick)
    }

    override fun onDestroy() { h.removeCallbacks(tick); hide(); inst = null; super.onDestroy() }

    private fun updateFg() {
        val u = getSystemService(UsageStatsManager::class.java); val now = System.currentTimeMillis()
        val ev = u.queryEvents(if (lastQ == 0L) now - 3600000 else lastQ - 1000, now); val e = UsageEvents.Event()
        while (ev.hasNextEvent()) { ev.getNextEvent(e); if (e.eventType == 1) fg = e.packageName }
        lastQ = now
    }

    fun poll() {
        updateFg()
        val apps = prefs().getStringSet("apps", emptySet())!!
        val want = fg in apps || (edit && fg == packageName)
        val w = wm.currentWindowMetrics.bounds.width()
        if (want && (!shown || w != sw)) { hide(); show() } else if (!want && shown) hide()
    }

    fun refresh() { if (shown) { hide(); show() } else poll() }
    fun setEdit(on: Boolean) { edit = on; poll(); views.forEach { it.invalidate() } }

    fun savePos(c: C, cx: Float, cy: Float) {
        val b = wm.currentWindowMetrics.bounds
        prefs().edit().putFloat(c.id + "x", cx / b.width()).putFloat(c.id + "y", cy / b.height()).apply()
    }

    private fun show() {
        val b = wm.currentWindowMetrics.bounds; sw = b.width()
        val d = resources.displayMetrics.density; val s = prefs().getInt("size", 100) / 100f
        for (c in CONTROLS) {
            val sz = (2 * c.r * d * s).toInt(); val w = if (c.kind == PILL) (sz * 1.8f).toInt() else sz
            val lp = WindowManager.LayoutParams(w, sz, TYPE_APPLICATION_OVERLAY,
                FLAG_NOT_FOCUSABLE or FLAG_LAYOUT_NO_LIMITS or FLAG_SPLIT_TOUCH, PixelFormat.TRANSLUCENT)
            lp.gravity = Gravity.TOP or Gravity.START
            lp.x = (prefs().getFloat(c.id + "x", c.fx) * b.width() - w / 2f).toInt()
            lp.y = (prefs().getFloat(c.id + "y", c.fy) * b.height() - sz / 2f).toInt()
            val v = CtlView(this, c, this); wm.addView(v, lp); views += v
        }
        shown = true
    }

    private fun hide() {
        views.forEach { try { wm.removeView(it) } catch (_: Throwable) {} }
        views.clear(); shown = false; Injector.releaseAll()
    }
}
