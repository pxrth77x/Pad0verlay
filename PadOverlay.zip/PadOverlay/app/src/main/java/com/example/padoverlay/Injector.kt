package com.example.padoverlay

import android.os.IBinder
import android.os.SystemClock
import android.view.InputDevice
import android.view.InputEvent
import android.view.KeyEvent
import android.view.MotionEvent
import org.lsposed.hiddenapibypass.HiddenApiBypass
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper
import java.lang.reflect.Method
import java.util.concurrent.Executors

/** Injects real gamepad key/axis events through Shizuku (runs as shell uid). */
object Injector {
    private var im: Any? = null
    private var inject: Method? = null
    private val io = Executors.newSingleThreadExecutor()
    private val axes = FloatArray(6) // X, Y, Z, RZ, LTRIGGER, RTRIGGER
    private val axisIds = intArrayOf(
        MotionEvent.AXIS_X, MotionEvent.AXIS_Y, MotionEvent.AXIS_Z,
        MotionEvent.AXIS_RZ, MotionEvent.AXIS_LTRIGGER, MotionEvent.AXIS_RTRIGGER
    )

    @Synchronized
    fun init(): Boolean {
        if (inject != null) return true
        return try {
            HiddenApiBypass.addHiddenApiExemptions("")
            val binder = ShizukuBinderWrapper(SystemServiceHelper.getSystemService("input"))
            val stub = Class.forName("android.hardware.input.IInputManager\$Stub")
            im = stub.getMethod("asInterface", IBinder::class.java).invoke(null, binder)
            inject = Class.forName("android.hardware.input.IInputManager")
                .getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType)
            true
        } catch (t: Throwable) { false }
    }

    private fun send(e: InputEvent) = io.execute {
        try { if (init()) inject!!.invoke(im, e, 0) } catch (_: Throwable) {}
    }

    fun key(code: Int, down: Boolean) {
        val t = SystemClock.uptimeMillis()
        send(KeyEvent(t, t, if (down) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, code, 0, 0,
            -1, 0, 0, InputDevice.SOURCE_GAMEPAD or InputDevice.SOURCE_DPAD))
    }

    @Synchronized
    fun axis(idx: Int, x: Float, y: Float? = null) {
        axes[idx] = x
        if (y != null) axes[idx + 1] = y
        val t = SystemClock.uptimeMillis()
        val p = MotionEvent.PointerProperties().apply { id = 0; toolType = MotionEvent.TOOL_TYPE_UNKNOWN }
        val c = MotionEvent.PointerCoords().apply { axisIds.forEachIndexed { i, a -> setAxisValue(a, axes[i]) } }
        send(MotionEvent.obtain(t, t, MotionEvent.ACTION_MOVE, 1, arrayOf(p), arrayOf(c),
            0, 0, 1f, 1f, -1, 0, InputDevice.SOURCE_JOYSTICK, 0))
    }

    fun releaseAll() { for (i in axes.indices) if (axes[i] != 0f) axis(i, 0f) }
}
