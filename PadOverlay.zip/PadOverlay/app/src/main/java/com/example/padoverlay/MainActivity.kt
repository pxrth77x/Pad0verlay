package com.example.padoverlay

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.AppOpsManager
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.widget.*
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var sp: SharedPreferences
    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        sp = getSharedPreferences("cfg", 0)
        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 0)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 40, 40, 40) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() }; root.addView(this) }
        fun slider(name: String, key: String, min: Int, max: Int, def: Int) {
            val tv = TextView(this); root.addView(tv)
            val sb = SeekBar(this).apply { this.max = max - min; progress = sp.getInt(key, def) - min }
            fun label() { tv.text = "$name: ${sb.progress + min}%" }
            label(); root.addView(sb)
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { sp.edit().putInt(key, v + min).apply(); label() }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { OverlayService.inst?.refresh() }
            })
        }
        status = TextView(this); root.addView(status)
        btn("1. Grant Shizuku permission") {
            try {
                if (!Shizuku.pingBinder()) toast("Start Shizuku first")
                else if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) Shizuku.requestPermission(1)
            } catch (t: Throwable) { toast("Shizuku is not installed/running") }
        }
        btn("2. Allow draw over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("3. Usage access (detects the running app)") { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        btn("4. Select apps / games") { pickApps() }
        slider("Button size", "size", 50, 200, 100)
        slider("Opacity", "alpha", 10, 100, 60)
        Switch(this).apply {
            text = "Edit layout (drag buttons)"
            setOnCheckedChangeListener { _, on -> OverlayService.inst?.applyEdit(on) }
            root.addView(this)
        }
        btn("Reset button positions") {
            sp.edit().apply { CONTROLS.forEach { remove(it.id + "x"); remove(it.id + "y") } }.apply()
            OverlayService.inst?.refresh()
        }
        btn("Start overlay service") { startForegroundService(Intent(this, OverlayService::class.java)) }
        btn("Stop overlay service") { stopService(Intent(this, OverlayService::class.java)) }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        val shz = try { Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED } catch (t: Throwable) { false }
        val ao = getSystemService(AppOpsManager::class.java)
        val usage = ao.unsafeCheckOpNoThrow("android:get_usage_stats", Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
        status.text = "Shizuku: ${if (shz) "OK" else "no"}   Overlay: ${if (Settings.canDrawOverlays(this)) "OK" else "no"}   " +
            "Usage: ${if (usage) "OK" else "no"}   Apps: ${sp.getStringSet("apps", emptySet())!!.size}"
    }

    private fun pickApps() {
        val pm = packageManager
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .distinctBy { it.first }.sortedBy { it.second.lowercase() }
        val sel = sp.getStringSet("apps", emptySet())!!.toMutableSet()
        AlertDialog.Builder(this).setTitle("Show gamepad in:")
            .setMultiChoiceItems(list.map { it.second }.toTypedArray(), BooleanArray(list.size) { list[it].first in sel }) { _, i, on ->
                if (on) sel += list[i].first else sel -= list[i].first
            }
            .setPositiveButton("Save") { _, _ -> sp.edit().putStringSet("apps", HashSet(sel)).apply(); onResume() }
            .setNegativeButton("Cancel", null).show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
